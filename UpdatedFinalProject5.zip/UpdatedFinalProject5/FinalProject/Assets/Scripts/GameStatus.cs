﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStatus : MonoBehaviour {

    public GameObject gameOverUI;
    public GameObject nextLevelUI;
    public GameObject winGameUI;


    public void PlayerDies()
    {
        //begin the Game Over animation
        gameOverUI.SetActive(true);
    }

    public void NextLevel()
    {
        //begin the animation to transition to the next level
        nextLevelUI.SetActive(true);
    }

    public void WinGame()
    {
        winGameUI.SetActive(true);
    }
}
