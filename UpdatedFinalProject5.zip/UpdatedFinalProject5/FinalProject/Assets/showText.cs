﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class showText : MonoBehaviour {

     public GameObject uiObject;

	// Use this for initialization
	void Start () {
          uiObject.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

     void onTriggerEnter(Collider player)
     {
          if (player.gameObject.tag == "player")
          {
               uiObject.SetActive(true);
               
          }
     }
}
