﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trampolineScript : MonoBehaviour {

    bool onTop;
    Animator anim;
    GameObject bouncer;
    public Vector2 velocity;

	// Use this for initialization
	void Start () {
        anim = gameObject.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnCollisionStay2D(Collision2D other)
    {
        if (onTop)
        {
            anim.SetBool("isStepped", true);
            bouncer = other.gameObject;
        }
    }

    void OnTriggerEnter2D()
    {
        onTop = true;
    }

    void OnTriggerExit2D()
    {
        onTop = false;
        anim.SetBool("isStepped", false);

    }

    void Bounce()
    {
        Debug.Log("Trampoline Jump");
        bouncer.GetComponent<Rigidbody2D>().velocity = velocity;
        //calling AaddForce has weird results 
        //bouncer.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 10), ForceMode2D.Impulse);
    }
}
