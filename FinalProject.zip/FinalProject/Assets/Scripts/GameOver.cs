﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour {

    //this script is called in the Game Over animation
	public void ReloadScene()
    {
        SceneManager.LoadScene("Prototype_1");
    }
}
