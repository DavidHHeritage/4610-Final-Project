﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerScore : MonoBehaviour {

    public float timeLeft = 120;
    public int playerScore;
    public GameObject timeLeftUI;
    public GameObject playerScoreUI;
    public GameStatus gameStatus;

    void Start(){
        DataManagement.datamanagement.LoadData();
    }

	// Update is called once per frame
	void Update () {
        timeLeft -= Time.deltaTime;
        timeLeftUI.gameObject.GetComponent<Text>().text = ("Time Left: " + (int)timeLeft);
        playerScoreUI.gameObject.GetComponent<Text>().text = ("Score: " + playerScore);
        if (timeLeft < 0.1f){
            SceneManager.LoadScene("Prototype_1");
        }
	}
    void OnTriggerEnter2D(Collider2D trig){
        if (trig.gameObject.name == "EndLevel"){
            CountScore();
            DataManagement.datamanagement.SaveData();
               //begin LevelComplete animation
               Debug.Log("collide");
            gameStatus.NextLevel();
        }
        if(trig.gameObject.name == "coinGold"){
            playerScore += 10;
           Destroy(trig.gameObject);
        }
        if (trig.gameObject.name == "slimeWalk1")
        {
            playerScore += 10;
        }
    }
    void CountScore(){
        playerScore = playerScore + (int)(timeLeft * 10);
        DataManagement.datamanagement.highScore = playerScore + (int)(timeLeft * 10);
        DataManagement.datamanagement.SaveData();
        //Debug.Log(DataManagement.datamanagement.highScore);
    }
}
