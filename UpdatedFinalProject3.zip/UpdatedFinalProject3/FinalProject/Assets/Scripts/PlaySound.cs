﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySound : MonoBehaviour {
     public AudioSource lvlComplete;

     // Use this for initialization
     void Start() {
          lvlComplete = GetComponent<AudioSource>();
     }

     // Update is called once per frame
     void Update() {

     }

     void OnCollistionEnter (Collision col)
     {
          if (col.gameObject.tag == "Finish")
          {
               lvlComplete.Play();
          }
     }
}
