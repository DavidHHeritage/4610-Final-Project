﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToFinalLevel : MonoBehaviour {

     //this script is called during the LevelComplete animation
     public void FinalLevel()
     {
          //go to next scene in the Build Settings list
          //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
          SceneManager.LoadScene("Final_Level");

     }
}