﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GoToNextLevel : MonoBehaviour {

     //this script is called during the LevelComplete animation
     public void NextLevel()
     {

          if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("Prototype_1"))
          {
               SceneManager.LoadScene("Prototype_2");
          }
          else
          {
               SceneManager.LoadScene("Final_Level");
          }
          //go to next scene in the Build Settings list
          //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
          

     }
}
